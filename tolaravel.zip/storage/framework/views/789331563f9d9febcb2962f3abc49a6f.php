<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8"/>
    <title>Chat UI - 4 Columns</title>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(file_exists(public_path('build/manifest.json')) || file_exists(public_path('hot'))): ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>


    <title><?php echo e($title ?? 'Page Title'); ?></title>
</head>

<body class="bg-gray-100 flex items-center justify-center">
<?php echo e($slot); ?>

</body>
</html>
<?php /**PATH D:\xampp\htdocs\tolaravel\resources\views/layouts/admin/app.blade.php ENDPATH**/ ?>